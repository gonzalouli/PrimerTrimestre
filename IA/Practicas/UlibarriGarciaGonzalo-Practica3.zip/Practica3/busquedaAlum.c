/*******************************************/
/* 		    BUSQUEDA.C                     */
/*						                   */
/* Asignatura: Inteligencia Artificial     */
/* Grado en Ingenieria Informatica - UCA   */
/*******************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "puzle.h"
#include "nodo.h"
#include "listaia.h"
#include "busquedaAlum.h"


void dispCamino(tNodo *nodo)
{
   if (nodo->padre==NULL)
   {
      printf("\n\nInicio:\n");
      dispEstado(nodo->estado);
   }
   else
   {
      dispCamino(nodo->padre);
      dispOperador(nodo->operador);
      dispEstado(nodo->estado);
      printf("\n");
   }
}


void dispSolucion(tNodo *nodo)
{
   dispCamino(nodo);
   printf("Profundidad=%d\n",nodo->profundidad);
   printf("Coste=%d\n",nodo->costeCamino);
}


/* Crea el nodo raíz. */
tNodo *nodoInicial()
{
   tNodo *inicial=(tNodo *) malloc(sizeof(tNodo));

   inicial->estado=estadoInicial();
   inicial->padre=NULL;
   inicial->costeCamino=0;
   inicial->profundidad=0;
   return inicial;
}


int buscaRepe(tEstado *s, Lista L1){

int encontrado=0;

tNodo *extraido = (tNodo*)malloc(sizeof(tNodo));

for(int i=0 ;  i<L1->Lmax && encontrado==0 ;  i++){

   extraido = (tNodo*) ExtraerElem(L1,i);

   encontrado = iguales(extraido->estado,s);
}

return encontrado;
}





/* Expande un nodo. */
Lista expandir(tNodo *nodo)
{  
   unsigned op;
   Lista sucesores=CrearLista(MAXI);
  printf("\nLista de Sucesores de Actual: \n");
   for (op=1;op<=NUM_OPERADORES;op++)
   {
      if (esValido(op,nodo->estado))
      {
         tNodo *nuevo=(tNodo *) malloc(sizeof(tNodo));
         tEstado *s=(tEstado *) malloc(sizeof(tEstado));
         s=aplicaOperador(op,nodo->estado);
         nuevo=(tNodo *) malloc(sizeof(tNodo));
         nuevo->estado=s;
         nuevo->padre=nodo;
         nuevo->operador=op;
         nuevo->costeCamino=nodo->costeCamino + coste(op,nodo->estado);
         nuevo->profundidad=nodo->profundidad+1;
         
         if (!ListaLlena(sucesores)){
            
            InsertarUltimo((void *) nuevo,sucesores);
            dispEstado(nuevo->estado);
         }
      }
  }

   
  return sucesores;
}




int busqueda()
{  int nestados=0,nnodos=0;

   puts("Ha entrado");
   int objetivo=0;
   tNodo *Actual=(tNodo*) malloc(sizeof(tNodo));

   tNodo *Inicial=nodoInicial();
   tEstado *Final=estadoObjetivo();

   Lista Abiertos= (Lista)CrearLista(MAXI);
   Lista Sucesores;
   Lista Cerrados =(Lista)CrearLista(MAXI);

   InsertarUltimo((void *)Inicial, Abiertos);

   while (!ListaVacia(Abiertos) && !objetivo && !ListaLlena(Cerrados))
   {
      Actual= (void *) ExtraerPrimero(Abiertos);

      printf("\n ACTUAL: \n");

    dispEstado(Actual->estado);
      
      EliminarPrimero(Abiertos);
      objetivo=testObjetivo(Actual->estado);
           

	  if (!objetivo)
      {int repetido=buscaRepe(Actual->estado,Cerrados);
      ///estrategia de anchura
         if(!repetido){
            Sucesores = expandir(Actual); 
        
		       nestados++;
            
         printf("%d Estado visitado",nestados);
         Abiertos=Concatenar(Sucesores,Abiertos); ///sucesores,abiertos para profundidad
		   
            if(nnodos < Abiertos->Nelem);
               nnodos=Abiertos->Nelem; 
      } 
   }  
      printf("Numero de elementos en aiertos %d",nnodos);
    dispSolucion(Actual);
   getchar();
   return objetivo;
   }
}
