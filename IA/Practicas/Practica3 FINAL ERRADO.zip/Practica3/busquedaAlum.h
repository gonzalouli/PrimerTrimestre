/*******************************************/
/* 		    BUSQUEDA.H                     */
/*						                   */
/* Asignatura: Inteligencia Artificial     */
/* Grado en Ingenieria Informatica - UCA   */
/*******************************************/

#ifndef _BUSQUEDA_ALUM_H
#define _BUSQUEDA_ALUM_H


int busqueda();
int buscaRepe(tEstado *s, Lista L1);
Lista ordenar(Lista Abiertos,Lista Sucesores);
///Lista InsertarOrden(Lista Abiertos, tElemento *tElemento);
Lista insertar_orden(Lista abiertos, tNodo *n);
Lista a_estrella(Lista abiertos, Lista sucesores);
Lista voraz(Lista abiertos, Lista sucesores);

#endif
