#include <stdio.h>
#include "puzle.h"
#include "puzleAlum.c"



int main(){
 
tEstado *estado;

unsigned op;
puts("Dame un movimiento para realizar: 1.Arriba 2.Abajo 3.Derecha 4.Izquierda");

scanf("%d", &op);

esValido(op,estado);


}
